const express = require("express");
const path = require("path");
const multer = require("multer");
const FormData = require("form-data");
const axios = require("axios");
const fs = require("fs");

const app = express();
const upload = multer();
const PLANTNET_API_KEY = "2b105AqRU7zSXNlDin3ULpKuq";

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware to serve static files and parse JSON
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// Load herb data from JSON file with hot-reload
const herbDataPath = path.join(__dirname, "data", "herbs.json");
let herbData = loadHerbData();

function loadHerbData() {
  try {
    const rawData = fs.readFileSync(herbDataPath, "utf-8");
    const data = JSON.parse(rawData);
    console.log(`✅ Loaded ${data.length} herbs from database`);
    return data;
  } catch (error) {
    console.error("❌ Error loading herb data:", error);
    return [];
  }
}

// Watch for file changes
fs.watchFile(herbDataPath, (curr, prev) => {
  console.log("🔄 herbs.json changed, reloading...");
  const newData = loadHerbData();
  if (newData.length > 0) {
    herbData = newData;
    console.log(`✅ Updated herb database with ${herbData.length} entries`);
  }
});

// Validate herb data structure
function validateHerbData() {
  if (herbData.length > 0) {
    console.log("📋 Sample herb data structure:");
    console.log({
      "Botanical Name": herbData[0]["Botanical Name"],
      "Part Used": herbData[0]["Part Used"],
      "Available Properties": Object.keys(herbData[0])
    });
  }
  
  const requiredFields = [
    "Botanical Name", "Part Used", "Taste Intensity", "Predominant Taste",
    "Predominant Functional Group", "Predominant Phytochemical",
    "Potentiometric Meter Value (Estimated)", "pH (Estimated)",
    "HPTLC (Rf value example)", "FTIR (Key Peak example) cm^-2", "LC-MS (m/z example)"
  ];
  
  const missingFields = requiredFields.filter(field => 
    !herbData[0] || !herbData[0].hasOwnProperty(field)
  );
  
  if (missingFields.length > 0) {
    console.warn("⚠️ Missing fields in herb data:", missingFields);
  } else {
    console.log("✅ All required herb data fields present");
  }
}

// Function to get additional plant information from Wikipedia
async function getPlantDetails(scientificName) {
  try {
    const wikiResponse = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(scientificName)}`, {
      timeout: 5000,
      headers: {
        'User-Agent': 'PlantIdentificationBot/1.0'
      }
    });
    
    let description = wikiResponse.data.extract || '';
    if (description.length > 300) {
      description = description.substring(0, 300) + '...';
    }
    
    return {
      description: description,
      wikiUrl: wikiResponse.data.content_urls?.desktop?.page || null
    };
  } catch (error) {
    console.log(`ℹ️ Could not fetch additional details for ${scientificName}`);
    return {
      description: '',
      wikiUrl: null
    };
  }
}

// Improved matching function with multiple strategies
function findHerbMatch(plantScientificName, herbs) {
  if (!plantScientificName) return null;
  
  const plantName = plantScientificName.toLowerCase().trim();
  console.log(`   Looking for match for: "${plantName}"`);
  
  // Strategy 1: Exact match
  let match = herbs.find(herb => 
    herb["Botanical Name"].toLowerCase().trim() === plantName
  );
  if (match) {
    console.log(`   ✅ Exact match: ${match["Botanical Name"]}`);
    return match;
  }
  
  // Strategy 2: Remove author names and try again
  const plantNameWithoutAuthor = plantName.split(' ').slice(0, 2).join(' ');
  match = herbs.find(herb => 
    herb["Botanical Name"].toLowerCase().trim() === plantNameWithoutAuthor
  );
  if (match) {
    console.log(`   ✅ Match without author: ${match["Botanical Name"]}`);
    return match;
  }
  
  // Strategy 3: Genus match (first word)
  const plantGenus = plantName.split(' ')[0];
  match = herbs.find(herb => 
    herb["Botanical Name"].toLowerCase().trim().split(' ')[0] === plantGenus
  );
  if (match) {
    console.log(`   ✅ Genus match: ${match["Botanical Name"]}`);
    return match;
  }
  
  // Strategy 4: Contains match
  match = herbs.find(herb => 
    herb["Botanical Name"].toLowerCase().includes(plantName) ||
    plantName.includes(herb["Botanical Name"].toLowerCase())
  );
  if (match) {
    console.log(`   ✅ Contains match: ${match["Botanical Name"]}`);
    return match;
  }
  
  // Strategy 5: Fuzzy match by words
  const plantWords = plantName.split(' ');
  match = herbs.find(herb => {
    const herbWords = herb["Botanical Name"].toLowerCase().split(' ');
    return plantWords.some(word => herbWords.includes(word));
  });
  if (match) {
    console.log(`   ✅ Fuzzy word match: ${match["Botanical Name"]}`);
    return match;
  }
  
  console.log(`   ❌ No match found for: ${plantName}`);
  return null;
}

// Home page → display herb cards
app.get("/", (req, res) => {
  res.render("index", { herbs: herbData });
});

// Herb detail page
app.get("/herb/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const herb = herbData[id];
  if (!herb) return res.status(404).send("Herb not found");
  res.render("herbDetails", { herb });
});

// Enhanced plant identification route
app.post("/identify", upload.single("images"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: "No image uploaded" });

    const formData = new FormData();
    formData.append("images", req.file.buffer, req.file.originalname);
    formData.append("organs", "auto");

    console.log("🔍 Calling plant identification API...");

    try {
      const response = await axios.post(
        `https://my-api.plantnet.org/v2/identify/all?api-key=${PLANTNET_API_KEY}`,
        formData,
        { headers: formData.getHeaders(), timeout: 30000 }
      );

      const plantNetResults = response.data;

      if (!plantNetResults.results || plantNetResults.results.length === 0) {
        return res.json({ 
          success: false, 
          message: "❌ Could not identify any plants from this image. Please try with a clearer image of the plant." 
        });
      }

      console.log(`✅ API returned ${plantNetResults.results.length} possible plants`);
      
      // DEBUG: Log all plant names from API
      console.log("🌱 Plants from API:");
      plantNetResults.results.forEach((plant, i) => {
        const sciName = plant?.species?.scientificNameWithoutAuthor || plant?.species?.scientificName || "Unknown";
        console.log(`   ${i + 1}. ${sciName} (${(plant.score * 100).toFixed(1)}%)`);
      });

      // DEBUG: Log all herbs in database
      console.log("📚 Herbs in database:");
      herbData.forEach((herb, i) => {
        console.log(`   ${i + 1}. ${herb["Botanical Name"]}`);
      });

      // Enhanced matching with herb database
      console.log("🔍 Matching with herb database...");
      
      let bestMatch = null;
      
      for (let i = 0; i < plantNetResults.results.length && i < 5; i++) {
        const plant = plantNetResults.results[i];
        const sciName = plant?.species?.scientificNameWithoutAuthor || plant?.species?.scientificName || "";
        
        if (sciName) {
          const matchedHerb = findHerbMatch(sciName, herbData);
          
          if (matchedHerb) {
            console.log(`✅ MATCH FOUND: ${sciName} → ${matchedHerb["Botanical Name"]}`);
            bestMatch = {
              plantData: plant,
              herbData: matchedHerb,
              scientificName: sciName,
              confidence: plant.score,
              matchIndex: i
            };
            break;
          }
        }
      }

      if (bestMatch) {
        const { plantData, herbData: matchedHerb, scientificName, confidence } = bestMatch;
        const confidencePercent = (confidence * 100).toFixed(1);
        const family = plantData?.species?.family?.scientificNameWithoutAuthor || "Unknown";
        const genus = plantData?.species?.genus?.scientificNameWithoutAuthor || "Unknown";
        const commonName = plantData?.species?.commonNames?.[0] || "Unknown";

        console.log(`🎯 Displaying herb details for: ${scientificName}`);

        // Get additional botanical information
        let additionalDetails = { description: '', wikiUrl: null };
        try {
          additionalDetails = await getPlantDetails(scientificName);
        } catch (detailError) {
          console.log("Could not fetch additional botanical details");
        }

        // Format the complete response
        let finalMessage = `🌿
MEDICINAL HERB IDENTIFIED!


Botanical Name: ${scientificName}
Common Name: ${commonName}
Family: ${family}
Genus: ${genus}


🌿 MEDICINAL HERB INFORMATION:
• Botanical Name: ${matchedHerb["Botanical Name"]}
• Part Used: ${matchedHerb["Part Used"]}
• Taste Intensity: ${matchedHerb["Taste Intensity"]}
• Predominant Taste: ${matchedHerb["Predominant Taste"]}
• Functional Group: ${matchedHerb["Predominant Functional Group"]}
• Phytochemical: ${matchedHerb["Predominant Phytochemical"]}

🧪 CHEMICAL ANALYSIS:
• Potentiometric Value: ${matchedHerb["Potentiometric Meter Value (Estimated)"]}
• pH: ${matchedHerb["pH (Estimated)"]}
• HPTLC (Rf value): ${matchedHerb["HPTLC (Rf value example)"]}
• FTIR Peak: ${matchedHerb["FTIR (Key Peak example) cm^-2"]}
• LC-MS: ${matchedHerb["LC-MS (m/z example)"]}`;

        // Add botanical description if available
        if (additionalDetails.description) {
          finalMessage += `\n\n📖 Botanical Description:\n${additionalDetails.description}`;
        }

        // Show other suggestions
        if (plantNetResults.results.length > 1) {
          const otherSuggestions = plantNetResults.results
            .filter((plant, index) => index !== bestMatch.matchIndex)
            .slice(0, 3)
            .map((plant, index) => {
              const name = plant?.species?.scientificNameWithoutAuthor || plant?.species?.scientificName || "Unknown";
              const common = plant?.species?.commonNames?.[0] || "";
              const conf = (plant?.score * 100).toFixed(1);
              return `${index + 1}. ${name}${common ? ` (${common})` : ''} - ${conf}%`;
            }).join('\n');

          if (otherSuggestions) {
            finalMessage += `\n\n🔍 OTHER POSSIBLE IDENTIFICATIONS:\n${otherSuggestions}`;
          }
        }

        if (additionalDetails.wikiUrl) {
          finalMessage += `\n\n🔗 Reference: ${additionalDetails.wikiUrl}`;
        }

        res.json({
          success: true,
          message: finalMessage,
          plantInfo: {
            scientificName: scientificName,
            commonName: commonName,
            family: family,
            genus: genus,
            confidence: confidencePercent,
            hasHerbMatch: true,
            matchPosition: bestMatch.matchIndex + 1
          },
          herbData: matchedHerb,
          plantNetResults: plantNetResults
        });

      } else {
        console.log("❌ No matches found in herb database");
        
        const topPlant = plantNetResults.results[0];
        const sciName = topPlant?.species?.scientificNameWithoutAuthor || topPlant?.species?.scientificName || "Unknown";
        const commonName = topPlant?.species?.commonNames?.[0] || "Unknown";
        const confidencePercent = (topPlant.score * 100).toFixed(1);
        const family = topPlant?.species?.family?.scientificNameWithoutAuthor || "Unknown";
        const genus = topPlant?.species?.genus?.scientificNameWithoutAuthor || "Unknown";

        // Show results but indicate no herb match
        const allSuggestions = plantNetResults.results.slice(0, 5).map((plant, index) => {
          const name = plant?.species?.scientificNameWithoutAuthor || plant?.species?.scientificName || "Unknown";
          const common = plant?.species?.commonNames?.[0] || "";
          const conf = (plant?.score * 100).toFixed(1);
          return `${index + 1}. ${name}${common ? ` (${common})` : ''} - ${conf}%`;
        }).join('\n');

        const noMatchMessage = `🌿
PLANT IDENTIFIED


Botanical Name: ${sciName}
Common Name: ${commonName}
Family: ${family}
Genus: ${genus}
Confidence: ${confidencePercent}%

❌ NOT FOUND IN MEDICINAL HERB DATABASE

🔍 POSSIBLE IDENTIFICATIONS:
${allSuggestions}

💡 This plant was successfully identified but is not in our medicinal herb collection.

📋 Our database contains these medicinal herbs:
${herbData.slice(0, 5).map((herb, i) => `${i + 1}. ${herb["Botanical Name"]}`).join('\n')}`;

        res.json({
          success: true,
          message: noMatchMessage,
          plantInfo: {
            scientificName: sciName,
            commonName: commonName,
            family: family,
            genus: genus,
            confidence: confidencePercent,
            hasHerbMatch: false
          },
          plantNetResults: plantNetResults,
          availableHerbs: herbData.map(herb => herb["Botanical Name"])
        });
      }

    } catch (apiError) {
      console.error("❌ API Error:", apiError.message);
      res.status(500).json({ 
        success: false, 
        message: "❌ Identification service is currently unavailable. Please try again later or search directly by botanical name.", 
        error: apiError.message 
      });
    }

  } catch (err) {
    console.error("Plant identification error:", err.message);
    res.status(500).json({ 
      success: false, 
      message: "Failed to process image. Please try again with a clearer image.", 
      error: err.message 
    });
  }
});

// Enhanced botanical name search endpoint with better matching
app.post("/search-herb", (req, res) => {
  const { botanicalName } = req.body;
  
  if (!botanicalName) {
    return res.status(400).json({ success: false, message: "Botanical name required" });
  }
  
  console.log(`🔍 Searching for herb: "${botanicalName}"`);
  console.log(`📚 Available herbs: ${herbData.map(h => h["Botanical Name"]).join(', ')}`);
  
  // Enhanced search with multiple matching strategies
  const searchTerm = botanicalName.toLowerCase().trim();
  
  const matchedHerbs = herbData.filter(herb => {
    const herbName = herb["Botanical Name"].toLowerCase();
    
    // Exact match
    if (herbName === searchTerm) return true;
    
    // Contains match
    if (herbName.includes(searchTerm) || searchTerm.includes(herbName)) return true;
    
    // Word match
    const searchWords = searchTerm.split(' ');
    const herbWords = herbName.split(' ');
    return searchWords.some(word => herbWords.includes(word));
  });
  
  if (matchedHerbs.length > 0) {
    const herb = matchedHerbs[0];
    console.log(`✅ Found match: ${herb["Botanical Name"]}`);
    
    const herbDetails = `🌿
MEDICINAL HERB FOUND


Botanical Name: ${herb["Botanical Name"]}


🌿 MEDICINAL HERB INFORMATION:
• Botanical Name: ${herb["Botanical Name"]}
• Part Used: ${herb["Part Used"]}
• Taste Intensity: ${herb["Taste Intensity"]}
• Predominant Taste: ${herb["Predominant Taste"]}
• Functional Group: ${herb["Predominant Functional Group"]}
• Phytochemical: ${herb["Predominant Phytochemical"]}

🧪 CHEMICAL ANALYSIS:
• Potentiometric Value: ${herb["Potentiometric Meter Value (Estimated)"]}
• pH: ${herb["pH (Estimated)"]}
• HPTLC (Rf value): ${herb["HPTLC (Rf value example)"]}
• FTIR Peak: ${herb["FTIR (Key Peak example) cm^-2"]}
• LC-MS: ${herb["LC-MS (m/z example)"]}`;

    res.json({
      success: true,
      message: herbDetails,
      herbData: herb,
      totalMatches: matchedHerbs.length
    });
  } else {
    console.log(`❌ No direct match found for: "${botanicalName}"`);
    
    // Try to find suggestions
    const suggestions = herbData
      .filter(herb => {
        const herbName = herb["Botanical Name"].toLowerCase();
        // Check if any word matches
        const searchWords = searchTerm.split(' ');
        const herbWords = herbName.split(' ');
        return searchWords.some(word => 
          herbWords.some(herbWord => herbWord.startsWith(word) || word.startsWith(herbWord))
        );
      })
      .slice(0, 5)
      .map(herb => herb["Botanical Name"]);

    console.log(`💡 Suggestions: ${suggestions.join(', ')}`);

    res.json({
      success: false,
      message: `❌ No herb found with botanical name containing "${botanicalName}"`,
      suggestions: suggestions
    });
  }
});

// Get all available herbs endpoint
app.get("/herbs-list", (req, res) => {
  const herbsList = herbData.map((herb, index) => ({
    id: index,
    botanicalName: herb["Botanical Name"],
    partUsed: herb["Part Used"],
    taste: herb["Predominant Taste"]
  }));
  
  res.json({
    success: true,
    totalHerbs: herbData.length,
    herbs: herbsList
  });
});

// Debug endpoint to check herb data
app.get("/debug-herbs", (req, res) => {
  res.json({
    totalHerbs: herbData.length,
    sampleHerb: herbData[0] || "No herbs loaded",
    allHerbs: herbData.map(h => h["Botanical Name"]),
    lastUpdated: new Date().toISOString()
  });
});

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({ 
    status: "OK", 
    timestamp: new Date().toISOString(),
    herbsLoaded: herbData.length,
    apiConfigured: !!PLANTNET_API_KEY
  });
});

// Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🌿 Herb Identification Server running at http://localhost:${PORT}`);
  validateHerbData();
  console.log(`🔑 API configured: ${!!PLANTNET_API_KEY}`);
  console.log('📡 Available endpoints:');
  console.log('  GET  / - Home page');
  console.log('  POST /identify - Plant identification');
  console.log('  POST /search-herb - Direct herb search');
  console.log('  GET  /herbs-list - List all herbs');
  console.log('  GET  /debug-herbs - Debug herb data');
  console.log('  GET  /health - Health check');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Server shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Server shutting down gracefully...');
  process.exit(0);
});