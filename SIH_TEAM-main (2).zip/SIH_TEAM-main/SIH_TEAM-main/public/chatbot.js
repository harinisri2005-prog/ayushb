document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("chatbot-container");

  container.innerHTML = `
    <button id="chatbot-button">💬</button>
    <div id="chat-window">
      <div id="chat-header">
        🌿 Plant Identification Assistant
        <button id="chat-close">✕</button>
      </div>
      <div id="chat-messages">
        <div class="message bot-message">
          <strong>Bot:</strong> Welcome! Upload a plant image or drag and drop it here and I'll help identify it for you. 🌱
        </div>
      </div>
      <div id="drag-drop-area">
        <div id="drag-drop-content">
          
          <label for="plant-image" class="file-select-btn">Choose File</label>
          <input type="file" id="plant-image" accept="image/*" style="display: none;" />
        </div>
        <div id="image-preview" style="display: none;">
          <img id="preview-img" src="" alt="Selected image" />
          <button id="remove-image">✕ Remove</button>
        </div>
      </div>
      <form id="chat-form">
        <button type="submit" id="identify-btn" disabled>🔍 Identify Plant</button>
      </form>
      
    </div>
  `;

  const button = document.getElementById("chatbot-button");
  const chatWindow = document.getElementById("chat-window");
  const chatMessages = document.getElementById("chat-messages");
  const chatForm = document.getElementById("chat-form");
  const closeButton = document.getElementById("chat-close");
  const dragDropArea = document.getElementById("drag-drop-area");
  const fileInput = document.getElementById("plant-image");
  const imagePreview = document.getElementById("image-preview");
  const previewImg = document.getElementById("preview-img");
  const removeImageBtn = document.getElementById("remove-image");
  const identifyBtn = document.getElementById("identify-btn");
  const searchInput = document.getElementById("search-input");
  const searchBtn = document.getElementById("search-btn");

  let selectedFile = null;

  // Open chat in fullscreen
  button.addEventListener("click", () => {
    chatWindow.style.display = "flex";
    document.body.style.overflow = "hidden";
  });

  // Close chat
  closeButton.addEventListener("click", () => {
    chatWindow.style.display = "none";
    document.body.style.overflow = "auto";
  });

  // Close chat when clicking outside
  chatWindow.addEventListener("click", (e) => {
    if (e.target === chatWindow) {
      chatWindow.style.display = "none";
      document.body.style.overflow = "auto";
    }
  });

  // Drag and drop functionality
  dragDropArea.addEventListener("dragover", (e) => {
    e.preventDefault();
    dragDropArea.classList.add("drag-over");
  });

  dragDropArea.addEventListener("dragleave", (e) => {
    e.preventDefault();
    dragDropArea.classList.remove("drag-over");
  });

  dragDropArea.addEventListener("drop", (e) => {
    e.preventDefault();
    dragDropArea.classList.remove("drag-over");

    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type.startsWith("image/")) {
      handleFileSelect(files[0]);
    } else {
      addBotMessage("⚠️ Please drop a valid image file (JPEG, PNG, etc.).");
    }
  });

  // File input change
  fileInput.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
      handleFileSelect(e.target.files[0]);
    }
  });

  // Handle file selection and preview
  function handleFileSelect(file) {
    if (file.size > 10 * 1024 * 1024) {
      addBotMessage("⚠️ Image size too large. Please select an image smaller than 10MB.");
      return;
    }

    selectedFile = file;

    const reader = new FileReader();
    reader.onload = (e) => {
      previewImg.src = e.target.result;
      document.getElementById("drag-drop-content").style.display = "none";
      imagePreview.style.display = "block";
      identifyBtn.disabled = false;
      chatMessages.scrollTop = chatMessages.scrollHeight;
    };
    reader.readAsDataURL(file);
  }

  // Remove image
  removeImageBtn.addEventListener("click", () => {
    selectedFile = null;
    fileInput.value = "";
    document.getElementById("drag-drop-content").style.display = "block";
    imagePreview.style.display = "none";
    identifyBtn.disabled = true;
  });

  // Helper function to format message text
  function formatMessage(text) {
  // Preserve the exact formatting from the server
  return text
    .replace(/\n/g, '<br>') // Convert newlines to <br> tags
    .replace(/(🌿|🔍|🧪|📖|🔗|❌|✅|⚠️|💡|📋)/g, '<span class="emoji">$1</span>')
    .replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener" class="message-link">$1</a>');
}

  // Helper function to add formatted message with typing indicator
  function addBotMessage(messageText, showTyping = true) {
    if (showTyping) {
      const typingIndicator = document.createElement("div");
      typingIndicator.className = "typing-indicator";
      typingIndicator.innerHTML = `<strong>Bot:</strong> <span class="typing-dots"><span>.</span><span>.</span><span>.</span></span>`;
      chatMessages.appendChild(typingIndicator);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    setTimeout(() => {
      const typingIndicator = document.querySelector(".typing-indicator");
      if (typingIndicator) {
        typingIndicator.remove();
      }

      const botMessage = document.createElement("div");
      botMessage.className = "message bot-message";
      
      const formattedMessage = formatMessage(messageText);
      botMessage.innerHTML = `<strong>Bot:</strong> ${formattedMessage}`;
      
      chatMessages.appendChild(botMessage);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }, showTyping ? 1000 : 0);
  }

  // Helper function to add user message
  function addUserMessage(messageText) {
    const userMessage = document.createElement("div");
    userMessage.className = "message user-message";
    userMessage.innerHTML = `<strong>You:</strong> ${messageText}`;
    chatMessages.appendChild(userMessage);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // Plant identification form submission
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!selectedFile) {
      addBotMessage("⚠️ Please select an image first by clicking 'Choose File' or dragging an image.");
      return;
    }

    addUserMessage(`Uploaded image: "${selectedFile.name}" for identification 🔍`);

    identifyBtn.disabled = true;
    identifyBtn.textContent = "🔄 Processing...";

    const formData = new FormData();
    formData.append("images", selectedFile);

    try {
      const res = await fetch("/identify", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (data.success) {
        addBotMessage(data.message);
      } else {
        addBotMessage(data.message || "❌ Sorry, I couldn't identify this plant. Please try with a clearer image.");
      }

      removeImageBtn.click();
    } catch (error) {
      console.error("Error:", error);
      addBotMessage("❌ Sorry, there was an error processing your image. Please try again. 🌿");
    } finally {
      identifyBtn.disabled = false;
      identifyBtn.textContent = "🔍 Identify Plant";
    }
  });

  // Search functionality
  async function performSearch(query) {
    if (!query.trim()) {
      addBotMessage("⚠️ Please enter a botanical name to search (e.g., 'Terminalia bellirica').");
      return;
    }

    addUserMessage(`Searching for: "${query}"`);

    try {
      const response = await fetch('/search-herb', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ botanicalName: query })
      });

      const data = await response.json();

      if (data.success) {
        addBotMessage(data.message);
        if (data.totalMatches > 1) {
          addBotMessage(`💡 Found ${data.totalMatches} matching herbs. Showing the most relevant match.`);
        }
      } else {
        addBotMessage(data.message);
        if (data.suggestions && data.suggestions.length > 0) {
          addBotMessage(`💡 **Try these similar herbs:**\n${data.suggestions.map((name, i) => `${i + 1}. ${name}`).join('\n')}`);
        }
      }
    } catch (error) {
      console.error('Search error:', error);
      addBotMessage("❌ Sorry, there was an error with the search. Please try again.");
    }
  }

  // Search button click
  searchBtn.addEventListener("click", () => {
    const query = searchInput.value.trim();
    if (query) {
      performSearch(query);
      searchInput.value = "";
    }
  });

  // Search on Enter key
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      const query = searchInput.value.trim();
      if (query) {
        performSearch(query);
        searchInput.value = "";
      }
    }
  });

  // Add helpful tips after initialization
  setTimeout(() => {
    addBotMessage(`💡 **Quick Tips:**
• Upload clear plant images for best identification results
• Search directly by botanical name (e.g., "Terminalia bellirica")
• I can identify medicinal herbs and show their chemical properties
• Supported image formats: JPEG, PNG, WebP (max 10MB)`);
  }, 1500);
});